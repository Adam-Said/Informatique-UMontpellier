# Projet HAI502I Bases de Données
## Par : Arnaud C, Maxime B, Gatien H, Adam S
### Mise en place d'une base de donnée reprenant celle du jeu Clash Of Clans



### Schema entité-association de la BDD :
![Schema EA](https://github.com/Gaiko19/ProjetBDD/blob/main/documents/schemaEA-BDD.svg)
