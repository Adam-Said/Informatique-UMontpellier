@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.exo2.tp2.hai704i/")
package hai704i.tp2.exo2.client;
