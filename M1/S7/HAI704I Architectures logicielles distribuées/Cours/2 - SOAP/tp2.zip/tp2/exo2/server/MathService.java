package hai704i.tp2.exo2.server;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface MathService {
	@WebMethod
	int add(int a, int b);
	
	@WebMethod
	int subtract(int a, int b);
	
	@WebMethod
	int multiply(int a, int b);
	
	@WebMethod
	int divide(int a, int b) throws IllegalArgumentException;
}
