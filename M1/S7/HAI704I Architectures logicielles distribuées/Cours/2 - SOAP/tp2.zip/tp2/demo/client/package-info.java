@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.demo.tp2.hai704i/")
package hai704i.tp2.demo.client;
