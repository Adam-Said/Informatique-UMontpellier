package hai704i.tp2.demo.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException() {
		
	}
	
	public EmployeeNotFoundException(String message) {
		super(message);
	}
}
