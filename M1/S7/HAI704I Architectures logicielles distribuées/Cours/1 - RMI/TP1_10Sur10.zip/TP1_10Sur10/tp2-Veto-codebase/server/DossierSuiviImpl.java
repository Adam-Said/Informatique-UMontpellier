//package tp2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class DossierSuiviImpl extends UnicastRemoteObject implements IDossierSuivi{
    
    private String etat;

    public DossierSuiviImpl() throws RemoteException{
        this.etat="Bonne santé";
    }

    public void setEtat(String e) throws RemoteException{
        this.etat = e;
    }

    public String getEtat() throws RemoteException{
        return this.etat;
    }
}