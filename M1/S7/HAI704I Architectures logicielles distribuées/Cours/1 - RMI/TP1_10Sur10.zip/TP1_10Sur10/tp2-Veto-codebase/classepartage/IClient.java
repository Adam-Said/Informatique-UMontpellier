import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IClient extends Remote{
    void startClient() throws RemoteException;
    void lookupCabinet(String cabinet) throws RemoteException;
    void addPatient(String nomPatient, String nomEspece, String ddn, String nomMaitre) throws RemoteException;
    void affichePatients() throws RemoteException;
    void addPatientReptile() throws RemoteException;
    void alerteClient(String s) throws RemoteException;
}