//package tp2;

import java.io.Serializable;

public class Espece implements Serializable{
    
    public String nom_espece;

    public Espece(String e){
        this.nom_espece = e;
    }
    
    public void setEspece(String e){
        this.nom_espece = e;
    }

    public String getEspece(){
        return this.nom_espece;
    }

    public String toString(){
        return this.nom_espece.toString();
    }
}