//package server;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;

public class Server {

	public Server() {}


	public static void main(String args[]) throws RemoteException {
        CabinetImpl cabinet = new CabinetImpl();
		cabinet.startCabinet();
	}
}