#!/bin/bash

tableau=( $(ps -aux | grep rmiregistry | awk '{print $2}') )
tableau2=( $(ps -aux | grep rmiregistry | awk '{print $11}') )
for i in ${!tableau[@]};do
if [ ${tableau2[i]} = "rmiregistry" ]; then
    echo ${tableau[i]}
    kill -9 ${tableau[i]}
fi
done