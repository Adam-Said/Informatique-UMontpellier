//package tp2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface ICabinet extends Remote{
    void addClient(IClient c) throws RemoteException;
    void delClient(IClient c) throws RemoteException;
    void addPatient(String n_animal, String t_animal, String ddn_animal, String n_maitre) throws RemoteException;
    void addPatient(String n_animal, Espece t_animal, String ddn_animal, String n_maitre) throws RemoteException;
    ArrayList<IAnimal> getPatients() throws RemoteException;
    IAnimal getPatient(String n) throws RemoteException;
    void alerte(String s) throws RemoteException;
}
