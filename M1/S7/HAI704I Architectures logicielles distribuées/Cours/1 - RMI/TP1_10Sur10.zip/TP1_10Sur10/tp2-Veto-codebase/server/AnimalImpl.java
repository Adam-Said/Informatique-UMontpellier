//package tp2;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AnimalImpl extends UnicastRemoteObject implements IAnimal {
    private String nom_animal;
    private Espece espece_animal;
    private String ddn_animal;
    private String nom_maitre;
    private DossierSuiviImpl dossier;

	public AnimalImpl(String n_animal, Espece t_animal, String ddn_animal, String n_maitre) throws RemoteException{
        this.nom_animal = n_animal;
        this.espece_animal = t_animal;
        this.ddn_animal = ddn_animal;
        this.nom_maitre = n_maitre;
        this.dossier = new DossierSuiviImpl();
	}
	
    public String getNomAnimal() throws RemoteException{
    	return this.nom_animal;
    }

    public String getNomMaitre() throws RemoteException{
    	return this.nom_maitre;
    }

    public String getEtat() throws RemoteException{
        return this.dossier.getEtat();
    }

    public void setEtat(String e) throws RemoteException{
        this.dossier.setEtat(e);
    }

    public DossierSuiviImpl getDossier() throws RemoteException{
        return this.dossier;
    }

    public void setEspece(Espece e){
        this.espece_animal = e;
    }

    public Espece getEspece(){
        return this.espece_animal;
    }

	public String getInfos() throws RemoteException {
        String s = "";
        s+="Nom de l'animal : "+this.nom_animal+"\n";
        s+="Espece de l'animal : "+this.espece_animal.toString()+"\n";
        s+="Date de naissance de l'animal : "+this.ddn_animal+"\n";
        s+="Nom du maitre : "+this.nom_maitre+"\n";
		return s;
	}
}