Solal Goldstein - 21608984

Exécution :
- Lancer un premier terminal dans le dossier contenant le Makefile
- Exécuter la commande "make" (compilation)
- Exécuter la commande "make Serveur" (lancement du serveur)
- Lancer autant de terminal que de client souhaiter, et pour chaque éxécuter la commande "make Client"
- suivre les différentes instructions

--IMPORTANT--
- Pour quitter un client, entrer "0" (et non pas CTRL + C ou autre), sinon le client ne sera pas considéré comme "déconnecter" par le serveur
- Pour quitter le serveur, CTRL + C ou D, ou fermeture de la console son possible, mais cela ne ferme pas les clients
- La commande "make kill", éxécutée aussi par "make clean" ou "./kill_registry.sh" supprime tous les registry lancé par l'ordinateur (attention de ne pas en avoir d'autre ouvert)
- Pour éxcuter la commande précédente, il est sans doute nécessaire de donner des droits d'éxécution au fichier kill_registry.sh

Remarques :
- La commande 3 (lors du lancement d'un client) permettant de tester l'exercice 4, ajoute un Reptile comme espèce alors que cette classe n'est présente que dans le dossier Client (utilisation codebase).
- Pour envoyer des messages du serveur au client, la classe Cabinet possède une arraylist des clients qui se connectent au serveur, ces les clients eux-mêmes qui s'y ajoute lors de leurs créations. 
