//package tp2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class CabinetImpl extends UnicastRemoteObject implements ICabinet{
    ArrayList<IAnimal> liste_patient;
    ArrayList<IClient> liste_client;

    public CabinetImpl() throws RemoteException{
        liste_patient = new ArrayList<IAnimal>();
        liste_client = new ArrayList<IClient>();
    }

    public void startCabinet() throws RemoteException{
        System.setProperty("java.security.policy", "./security.policy");
		SecurityManager securityManager = new SecurityManager();
		System.setSecurityManager(securityManager);
		System.setProperty("java.rmi.server.codebase","file:./client/");
        try {
			Registry registry = LocateRegistry.createRegistry(1099);
			if (registry==null){
				System.err.println("RmiRegistry not found");
			}else{
				registry.bind("Cabinet", this);
				System.out.println("Server ready");
			}
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
    }

    public void addClient(IClient c) throws RemoteException{
        this.liste_client.add(c);
    }

    public void delClient(IClient c) throws RemoteException{
        for(int i=0; i < liste_client.size(); i++){
            if(liste_client.get(i).equals(c)){
                liste_client.remove(i);
            }
        }
    }

    public void addPatient(String n_animal, String t_animal, String ddn_animal, String n_maitre) throws RemoteException{
        IAnimal a = new AnimalImpl(n_animal,new Espece(t_animal),ddn_animal,n_maitre);
        liste_patient.add(a);
        if(liste_patient.size() > 100){
            this.alerte("Il y a plus de 100 patients pris en charge.");
        }
    }

    public void addPatient(String n_animal, Espece t_animal, String ddn_animal, String n_maitre) throws RemoteException{
        IAnimal a = new AnimalImpl(n_animal,t_animal,ddn_animal,n_maitre);
        liste_patient.add(a);
        if(liste_patient.size() > 101){
            this.alerte("Il y a plus de 100 patients pris en charge.");
        }
    }

    public void alerte(String s) throws RemoteException{
        System.out.println(s);
        for(IClient c : this.liste_client){
            c.alerteClient(s);
        }
    }

    public ArrayList<IAnimal> getPatients() throws RemoteException{
        return liste_patient;
    }

    public IAnimal getPatient(String n) throws RemoteException{
        for(IAnimal a : liste_patient){
            if(a.getNomAnimal().equals(n)){
                return a;
            }
        }
        System.out.println("L'animal n'est pas connu.");
        return null;
    }
}
