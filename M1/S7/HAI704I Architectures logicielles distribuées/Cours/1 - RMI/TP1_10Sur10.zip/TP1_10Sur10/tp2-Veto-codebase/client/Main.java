import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) throws RemoteException {
        Client client = new Client();
		client.startClient();
		client.lookupCabinet("Cabinet");
		String saisie = "a";
		while(!saisie.equals("0")){

			System.out.println();
			System.out.println("Entrer une commande : ");
			System.out.println("0 : Fermer le client.");
			System.out.println("1 : Ajouter un animal.");
			System.out.println("2 : Voir les animaux actuellement pris en charge.");
			System.out.println("3 : Ajouter un reptile (test du codebase exercice 4) ");
			System.out.println("4 : ajouter 101 animal (test exercice 5) ");
			System.out.println("5 : test (affiche un message au serveur et à tous les clients)");
			System.out.println();

			Scanner scan = new Scanner(System.in);
			saisie = scan.next();

			if(saisie.equals("1")){
				System.out.println("Ajout d'un animal.");
				System.out.println("Nom de l'animal : ");
				String nAnimal = scan.next();
				System.out.println("Espèce : ");
				String nEspece = scan.next();
				System.out.println("Date de naissance : ");
				String ddn = scan.next();
				System.out.println("Nom du maitre : ");
				String nMaitre = scan.next();
				client.addPatient(nAnimal, nEspece, ddn, nMaitre);
			}
			else if(saisie.equals("2")){
				client.affichePatients();
			}

			else if(saisie.equals("3")){
				client.addPatientReptile();
			}

			else if(saisie.equals("4")){
				for(int i=1; i<102; i++){
					client.addPatient("Damlmatien"+i, "Dalmatien", "01012000", "Cruella");
				}
			}

			else if(saisie.equals("5")){
				client.alerteCabinet("Salut le serveur et tous les clients.");
			}
		}
		client.fermetureClient();
		System.out.println("- Fermeture du client.");
		System.exit(0);
	}
}