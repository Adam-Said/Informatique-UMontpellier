public class Reptile extends Espece {

    private String nom;
    private int temps_peremption;

    public Reptile(){
        super("Reptile");
    }
}