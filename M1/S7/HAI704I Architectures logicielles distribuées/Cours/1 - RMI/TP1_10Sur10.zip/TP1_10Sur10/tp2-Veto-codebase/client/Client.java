//package tp2;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Client extends UnicastRemoteObject implements IClient{
	private Registry registry;
	private ICabinet cabinet;
	public Client() throws RemoteException {
		this.registry = null;
		this.cabinet = null;
	}

	public void startClient() throws RemoteException{
		System.setProperty("java.security.policy", "./security.policy");
		SecurityManager securityManager = new SecurityManager();
		System.setSecurityManager(securityManager);
		try {
			this.registry = LocateRegistry.getRegistry(null);
			System.out.println("- Client connecté registry.");
		} catch (Exception e) {
			System.err.println("Client exception (Registry non trouvé): " + e.toString());
			e.printStackTrace();
		}
	}

	public void lookupCabinet(String c) throws RemoteException{
		try {
			this.cabinet = (ICabinet) registry.lookup(c);
			System.out.println("- Client connecté au cabinet vétérinaire.");
			this.cabinet.addClient(this);

		} catch (Exception e) {
			System.err.println("Client exception (Cabinet non trouvé): " + e.toString());
			e.printStackTrace();
		}
	}

	public void addPatient(String nomPatient, String nomEspece, String ddn, String nomMaitre) throws RemoteException{
		cabinet.addPatient(nomPatient,nomEspece,ddn,nomMaitre);
		System.out.println("- Patient ajouté.");
	}

	public void affichePatients() throws RemoteException{
		for(IAnimal a : cabinet.getPatients()){
			System.out.println(a.getInfos());
		}
	}

	public void addPatientReptile() throws RemoteException{
		Espece serpent = new Reptile();
		cabinet.addPatient("Serpentard",serpent,"156845","Voldemort");
	}

	public void fermetureClient() throws RemoteException{
		this.cabinet.delClient(this);
	}

	public void alerteCabinet(String s) throws RemoteException{
		this.cabinet.alerte(s);
	}

	public void alerteClient(String s) throws RemoteException{
		System.out.println(s);
	}
}
