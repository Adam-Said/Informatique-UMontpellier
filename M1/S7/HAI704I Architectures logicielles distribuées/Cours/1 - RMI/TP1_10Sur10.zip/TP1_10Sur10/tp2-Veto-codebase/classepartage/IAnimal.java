//package tp2;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IAnimal extends Remote{
    String getNomAnimal() throws RemoteException;
	String getNomMaitre() throws RemoteException;
    IDossierSuivi getDossier() throws RemoteException;
    void setEtat(String etat) throws RemoteException;
    String getEtat() throws RemoteException;
    String getInfos() throws RemoteException;
    Espece getEspece() throws RemoteException;
    void setEspece(Espece e) throws RemoteException;
}
