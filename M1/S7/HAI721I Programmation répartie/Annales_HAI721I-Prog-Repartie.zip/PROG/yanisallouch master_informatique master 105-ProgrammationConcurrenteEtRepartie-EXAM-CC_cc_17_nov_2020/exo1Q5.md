Cocher une réponse si elle peut être utilisée (seule)  pour mettre en place une exclusion mutuelle :
Veuillez choisir au moins une réponse :

Un verrou au sens mutex.
Un verrou au sens mutex et une variable conditionnelle.

Un segment de mémoire partagé et un tableau de sémaphores.

Un tableau de sémaphores.

Un segment de mémoire partagé.

Une variable conditionnelle.
Une file de messages.

