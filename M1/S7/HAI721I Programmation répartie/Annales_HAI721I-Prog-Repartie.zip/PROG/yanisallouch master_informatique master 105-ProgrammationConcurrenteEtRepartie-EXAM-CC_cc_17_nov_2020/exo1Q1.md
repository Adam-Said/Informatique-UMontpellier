Donner le nombre de sémaphores du tableau à utiliser pour résoudre le problème énoncé et  pour chaque sémaphore,  donner sa valeur initiale et expliquer son rôle. 

Modèle de réponse pour un sémaphore Si (sémaphore à l'indice i du tableau) 

Si : 

Valeur initiale : votre réponse 

Rôle : votre réponse
