Après avoir traiter les autres questions de cet exercice, quel est au finale le nombre minimum d'étiquettes permettant une exécution correcte de l'application :

2 * N + 2

4 * N

N

N + 2

 4 * N + 2

2 * N + 1

1

N+1

2 * N

4 * N + 1

un nombre différent des autres propositions.

