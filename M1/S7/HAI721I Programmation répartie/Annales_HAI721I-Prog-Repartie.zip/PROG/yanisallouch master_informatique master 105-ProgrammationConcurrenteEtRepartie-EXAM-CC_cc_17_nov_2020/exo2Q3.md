Le processus Collecteur  ...... (cocher une réponse si elle permet d'aboutir à un fonctionnement  correct de de toute l'application)

passera à msgrcv(...) la valeur 0 en étiquette afin de recevoir une donnée en provenance de n'importe quel processus Capteur.

passera à msgrcv(...) une valeur > 0 en étiquette afin de recevoir une donnée en provenance d'un processus Capteur. Cette étiquette sera la même pour tous les capteurs.



passera à msgrcv(...) une valeur > 0 en étiquette afin de recevoir une donnée en provenance d'un processus Capteur. Cette étiquette sera différente pur chaque capteur.

