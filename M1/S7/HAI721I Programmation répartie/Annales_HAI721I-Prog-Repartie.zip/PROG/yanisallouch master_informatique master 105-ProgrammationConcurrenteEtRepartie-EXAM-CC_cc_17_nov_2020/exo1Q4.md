La duplication d'un paquet peut se produire ... 
Veuillez choisir au moins une réponse :

au niveau de la couche application, si cette couche met en place un système d'accusé de réception et que le protocole de transport utilisé est UDP.

au niveau de la couche transport, si un routeur demande un renvoi de ce paquet.
au niveau de la couche transport, uniquement lorsqu'il y a perte de paquet.

