package calculettePrefixe;

public class Calculette {
	public static String version = "Préfixe";
	protected EtatCalculettePrefixe etatCourant;
	protected EtatCalculettePrefixe[] etats = new EtatCalculettePrefixe[3];
	double acc;
	String operateur;
	
	public Calculette(){
		etats[0] = new EOperateur(this); //etat no 1
		etats[1] = new ENombre1(this); //etat no 2
		etats[2] = new ENombre2(this); //etat no 3
		etatCourant = etats[0];
		acc = 0;
	}
	
	double getAcc(){return acc;}
	void setAcc(double v){acc = v;}
	String getOp(){return operateur;}
	
	void setOp(String v){operateur = v;}
	
	public void enter(String s) throws CalculetteException{
		//déléguer le traitement de la requète à l'état courant
		int etatSuivant = etatCourant.enter(s);
		//changer l'état courant (le -1 car en Java les tableau débutent à l'indice 0)
		etatCourant = etats[etatSuivant - 1];
	}
	
	public double getResult(){
		return acc;
	}
	
}
