package calculettePrefixe;

public class EOperateur extends EtatCalculettePrefixe {

	EOperateur(Calculette c) {
		super(c);
	}

	public int enter(String s) throws CalculetteException {

		// tester si s appartient à l'enum operations
		try {
			operations.valueOf(s);
			calc.setOp(s);
			return (2);
		} catch (java.lang.IllegalArgumentException e) {
			throw new CalculetteException(
					"" + s + " : operateur inconnu d'une " + 
					calc.getClass().getName());
		}
	}
}
