package calculettePrefixe;

public class TestCalculettePrefixe {

	public static void main(String[] args){
		Calculette c = new Calculette();
		c.enter("plus"); //etat 1 : stocke l'operation a effectuer dans un registre
		c.enter("10"); //etat 2 : stocke le nombre 10 dans acc (Accumulateur) 
		c.enter("15"); //etat 3 : 
		System.out.println(c.getResult());
		
		c.enter("mult"); //etat 1 : stocke l'operation a effectuer dans un registre
		c.enter("3"); //etat 2 : stocke le nombre 3 dans acc (Accumulateur) 
		c.enter("15"); //etat 3 : 
		System.out.println(c.getResult());
		
		//ceci doit signaler une exception
		//truc : operateur inconnu d'une calculette
		c.enter("truc");
		
	}
}