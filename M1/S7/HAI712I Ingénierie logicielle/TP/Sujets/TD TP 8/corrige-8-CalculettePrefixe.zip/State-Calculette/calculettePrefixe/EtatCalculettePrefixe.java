package calculettePrefixe;

abstract class EtatCalculettePrefixe {
	
	static protected enum operations {plus, moins, mult, div};
	
	abstract int enter(String s) throws CalculetteException;
	
	Calculette calc;
	
	EtatCalculettePrefixe(Calculette c){
		calc = c;
	}
}
