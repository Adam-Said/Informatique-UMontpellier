package calculettePrefixe;

class CalculetteException extends RuntimeException {
	static final long serialVersionUID = 0;
	public CalculetteException(String s){
		super(s);
	}
}
