package calculettePrefixe;


public class ENombre1 extends EtatCalculettePrefixe{

	ENombre1(Calculette c){super(c);}
	
	public int enter(String s) throws CalculetteException {
		try{calc.setAcc(Float.parseFloat(s));}
		catch (NumberFormatException e)
			{throw new CalculetteException("Entrez un nombre svp!");}
		
		//l'état suivant est un ENombre2 stocké en 3ieme position du tableau des états
		return(3);}
}
