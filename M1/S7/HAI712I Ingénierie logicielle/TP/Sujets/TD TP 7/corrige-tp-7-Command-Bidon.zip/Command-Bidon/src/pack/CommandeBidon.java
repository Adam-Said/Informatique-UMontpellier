package pack;

/**
 * @author ahmad
 * @modified cd
 */

public abstract class CommandeBidon implements ICommande {
	
	//volume deplacé par une commande
	protected int volDeplace;

}
