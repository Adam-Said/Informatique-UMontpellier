package pack;

/**
 * 
 * @author ahmad
 *
 */
public interface ICommande {
	
	public void execute();
	public void undo();
	
}
